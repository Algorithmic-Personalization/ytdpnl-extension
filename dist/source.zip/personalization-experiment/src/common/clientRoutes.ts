export const postCreateSession = '/api/session';
export const postCheckParticipantCode = '/api/check-participant-code';
export const getParticipantConfig = '/api/config';
export const postEvent = '/api/event';
export const getParticipantChannelSource = '/api/participant-channel-source';
