export default {
	'production-server-url': 'https://prod-example.com',
	'development-server-url': 'https://dev-example.com',
};
